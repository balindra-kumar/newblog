import { PostviewpipePipe } from './postviewpipe.pipe';

describe('PostviewpipePipe', () => {
  it('create an instance', () => {
    const pipe = new PostviewpipePipe();
    expect(pipe).toBeTruthy();
  });
});
