import { LinkfyPipe } from './linkfy.pipe';

describe('LinkfyPipe', () => {
  it('create an instance', () => {
    const pipe = new LinkfyPipe();
    expect(pipe).toBeTruthy();
  });
});
