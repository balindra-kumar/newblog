import { HtmlTransformPipe } from './html-transform.pipe';

describe('HtmlTransformPipe', () => {
  it('create an instance', () => {
    const pipe = new HtmlTransformPipe();
    expect(pipe).toBeTruthy();
  });
});
