import { Component } from '@angular/core';
declare var $:any
@Component({
  selector: 'app-topmenu',
  templateUrl: './topmenu.component.html',
  styleUrls: ['./topmenu.component.css']
})
export class TopmenuComponent {
ngOnInit():void{
  $(document).ready(function(){
    $('.nav-link').click(function(){
      window.scrollTo({
        top: 0,
        behavior: 'auto'
      })
    })
  })
}
}

