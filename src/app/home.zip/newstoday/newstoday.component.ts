import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';
declare var $:any;
@Component({
  selector: 'app-newstoday',
  templateUrl: './newstoday.component.html',
  styleUrls: ['./newstoday.component.css']
})
export class NewstodayComponent {

  postReadUrl = "http://balindra.com/post/read.php";
  postArrayData:any = [];

  //news category post show
  newsArrayData:any = [];
   newsReadUrl = "http://balindra.com/post/news.php";
   

   //Technology category post show
   techArrayData:any = [];

   techReadUrl = "http://balindra.com/post/tech.php";
  
   //Job category post show
   jobArrayData:any = [];
   jobReadUrl = "http://balindra.com/post/job.php";
  

   //Busines category post show
   busiArrayData:any = [];
   busiReadUrl = "http://balindra.com/post/business.php";
  

    //Health category post show
    healthArrayData:any = [];
    healthReadUrl = "http://balindra.com/post/health.php";
 

     //science category post show
     scienceArrayData:any = [];
     scienceReadUrl = "http://balindra.com/post/science.php";
   
   
    
  constructor(private http:HttpClient){

   this.http.get(this.postReadUrl,{responseType:'json'}).subscribe((data:any)=>{
    this.postArrayData=data;
    this.postArrayData=this.postArrayData.sort((b:any,a:any)=>{
      return new Date(b.post_update_date) < new Date(a.post_update_date);
    })

     //first getting the post view
    

   })
  
    //news category post show
   this.http.get(this.newsReadUrl,{responseType:'json'}).subscribe((data:any)=>{
    this.newsArrayData=data;
    this.newsArrayData=this.newsArrayData.sort((b:any,a:any)=>{
      return new Date(b.post_update_date) < new Date(a.post_update_date);
    })
   })

     //news category post show
     this.http.get(this.techReadUrl,{responseType:'json'}).subscribe((data:any)=>{
      this.techArrayData=data;
      this.techArrayData=this.techArrayData.sort((b:any,a:any)=>{
        return new Date(b.post_update_date) < new Date(a.post_update_date);
      })
     })

      //Job category post show
      this.http.get(this.jobReadUrl,{responseType:'json'}).subscribe((data:any)=>{
        this.jobArrayData=data;
        this.jobArrayData=this.jobArrayData.sort((b:any,a:any)=>{
          return new Date(b.post_update_date) < new Date(a.post_update_date);
        }) 
       })

       //Business category post show
      this.http.get(this.busiReadUrl,{responseType:'json'}).subscribe((data:any)=>{
        this.busiArrayData=data;
        this.busiArrayData=this.busiArrayData.sort((b:any,a:any)=>{
          return new Date(b.post_update_date) < new Date(a.post_update_date);
        }) 
       })
         //Health category post show
      this.http.get(this.healthReadUrl,{responseType:'json'}).subscribe((data:any)=>{
        this.healthArrayData=data;
        this.healthArrayData=this.healthArrayData.sort((b:any,a:any)=>{
          return new Date(b.post_update_date) < new Date(a.post_update_date);
        }) 
       })

           //Science category post show
       this.http.get(this.scienceReadUrl,{responseType:'json'}).subscribe((data1:any)=>{
        this.scienceArrayData=data1;
        this.scienceArrayData=this.scienceArrayData.sort((b:any,a:any)=>{
          return new Date(b.post_update_date) < new Date(a.post_update_date);
        }) 
       
        
       })
      
      
  }

 

  
  
  scrolltop(){
    window.scrollTo(0,0)
  }
}
