import { PostdatePipe } from './postdate.pipe';

describe('PostdatePipe', () => {
  it('create an instance', () => {
    const pipe = new PostdatePipe();
    expect(pipe).toBeTruthy();
  });
});
