import { Component } from '@angular/core';

@Component({
  selector: 'app-verticalads',
  templateUrl: './verticalads.component.html',
  styleUrls: ['./verticalads.component.css']
})
export class VerticaladsComponent {

}
